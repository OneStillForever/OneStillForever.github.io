from flask import Flask, render_template, request, jsonify, redirect, url_for
import yaml
import os
from collections import defaultdict
import re

app = Flask(__name__)

class HSRPManager:
    def __init__(self, inventory_path='inventory.yml'):
        self.inventory_path = inventory_path
        self.hsrp_data = []
        
    def load_inventory(self):
        """Load Ansible inventory file"""
        try:
            with open(self.inventory_path, 'r', encoding='utf-8') as file:
                inventory = yaml.safe_load(file)
                return inventory
        except FileNotFoundError:
            print(f"Inventory file {self.inventory_path} not found")
            return {}
    
    def parse_hsrp_config(self, config_text):
        """Parse HSRP configuration from device config"""
        hsrp_configs = []
        lines = config_text.split('\n')
        current_interface = None
        current_hsrp = {}
        
        for line in lines:
            line = line.strip()
            
            # Interface detection
            if line.startswith('interface '):
                current_interface = line.replace('interface ', '')
                current_hsrp = {'interface': current_interface}
            
            # HSRP standby commands
            elif line.startswith('standby ') and current_interface:
                parts = line.split()
                if len(parts) >= 3:
                    group_id = parts[1]
                    command = parts[2]
                    
                    if 'standbyip' not in current_hsrp:
                        current_hsrp['standbyip'] = group_id
                    
                    if command == 'ip':
                        current_hsrp['ip'] = parts[3] if len(parts) > 3 else ''
                    elif command == 'priority':
                        current_hsrp['priority'] = parts[3] if len(parts) > 3 else '100'
                    elif command == 'track':
                        current_hsrp['track'] = parts[3] if len(parts) > 3 else ''
                    
                    # If we have enough info, add to configs
                    if 'ip' in current_hsrp or 'priority' in current_hsrp:
                        # Check if this config already exists
                        existing = next((cfg for cfg in hsrp_configs if cfg.get('interface') == current_interface and cfg.get('standbyip') == group_id), None)
                        if not existing:
                            hsrp_configs.append(current_hsrp.copy())
                        else:
                            existing.update(current_hsrp)
        
        return hsrp_configs
    
    def get_hsrp_data(self):
        """Get HSRP data from all devices"""
        inventory = self.load_inventory()
        hsrp_data = []
        
        for device_name, config in sample_configs.items():
            hsrp_configs = self.parse_hsrp_config(config)
            for config in hsrp_configs:
                hsrp_data.append({
                    'standbyip': config.get('standbyip', ''),
                    'hostname': device_name,
                    'interface': config.get('interface', ''),
                    'priority': config.get('priority', '100'),
                    'track': config.get('track', '')
                })
        
        return hsrp_data
    
    def update_hsrp_config(self, hostname, standbyip, interface, priority, track):
        """Update HSRP configuration"""
        # In a real implementation, this would update the actual device configuration
        # For now, we'll just simulate the update
        print(f"Updating {hostname} - Standby {standbyip} on {interface}: Priority={priority}, Track={track}")
        return True

hsrp_manager = HSRPManager()

@app.route('/')
def index():
    """Display HSRP configuration overview"""
    hsrp_data = hsrp_manager.get_hsrp_data()
    return render_template('hsrp_view.html', hsrp_data=hsrp_data)

@app.route('/edit')
def edit():
    """Display editable HSRP configuration"""
    hsrp_data = hsrp_manager.get_hsrp_data()
    
    # Get available interfaces for track options
    interfaces = set()
    for item in hsrp_data:
        if item['track']:
            interfaces.add(item['track'])
    
    # Add some common interface options
    common_interfaces = ['GigabitEthernet0/1', 'GigabitEthernet0/2', 'GigabitEthernet0/3', 
                        'FastEthernet0/1', 'FastEthernet0/2', 'TenGigabitEthernet0/1']
    interfaces.update(common_interfaces)
    
    return render_template('hsrp_edit.html', hsrp_data=hsrp_data, interfaces=sorted(list(interfaces)))

@app.route('/update', methods=['POST'])
def update():
    """Handle HSRP configuration updates"""
    data = request.json
    
    hostname = data.get('hostname')
    standbyip = data.get('standbyip')
    interface = data.get('interface')
    priority = data.get('priority')
    track = data.get('track')
    
    # Validate priority (should be between 1-255)
    try:
        priority_int = int(priority)
        if not (1 <= priority_int <= 255):
            return jsonify({'success': False, 'error': 'Priority must be between 1 and 255'})
    except ValueError:
        return jsonify({'success': False, 'error': 'Priority must be a valid number'})
    
    # Update configuration
    success = hsrp_manager.update_hsrp_config(hostname, standbyip, interface, priority, track)
    
    if success:
        return jsonify({'success': True, 'message': 'Configuration updated successfully'})
    else:
        return jsonify({'success': False, 'error': 'Failed to update configuration'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
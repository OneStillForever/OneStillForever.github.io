from flask import Flask, render_template, request, jsonify
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    ports = parse_arp_output()
    return render_template('index.html', ports=ports)

@app.route('/interface/<action>')
def interface_action(action):
    port = request.args.get('port')
    if action in ['shutdown', 'noshutdown']:
        # 실제 Ansible 실행은 나중에 연결
        print(f"Ansible로 {port}에 대해 {action} 실행 예정")
        return jsonify({'status': 'ok', 'action': action, 'port': port})
    return jsonify({'status': 'error', 'message': '잘못된 명령어'})


def parse_arp_output():
    # Ansible 실행
    subprocess.run(["ansible-playbook", "/etc/ansible/show_arp.yml"])

    # 출력된 텍스트 읽기
    arp_lines = []
    with open("/tmp/arp_output.txt") as f:
        arp_lines = f.readlines()

    ports = {}

    for line in arp_lines:
        # 예: Internet  192.168.0.11  5   0023.abcdef01  ARPA   GigabitEthernet0/1
        parts = line.strip().split()
        if len(parts) >= 6 and parts[0] == "Internet":
            ip = parts[1]
            mac = parts[3]
            intf = parts[5]

            # 포트 이름으로 쓸 수 있는 형식이면 그대로 사용
            if "Ethernet" in intf:  # FastEthernet, GigabitEthernet 등 포함
                port = intf
            else:
                port = None  # 사용하지 않음

            if port:
                ports[port] = {"ip": ip, "mac": mac, "intf": intf}

    return ports

if __name__ == '__main__':
    app.run(debug=True)

# L2 intface on off
from flask import Flask, render_template, request, jsonify
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    ports = parse_interface_status()
    return render_template('index.html', ports=ports)

@app.route('/interface/<action>')
def interface_action(action):
    port = request.args.get('port')
    if action in ['shutdown', 'no shutdown']:
        # 예시: ansible-playbook 실행 (플레이북, 변수 등 경로 및 내용은 환경에 맞게 조정)
        cmd = [
            'ansible-playbook', '/etc/ansible/interface_control.yml',
            '-e', f"port={port} act='{action}'"
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                return jsonify({'status': 'ok', 'action': action, 'port': port})
            else:
                return jsonify({'status': 'error', 'message': result.stderr})
        except Exception as e:
            return jsonify({'status': 'error', 'message': str(e)})

    return jsonify({'status': 'error', 'message': '잘못된 명령어'})

def parse_interface_status():
    ports = {}

    try:
        with open('/tmp/int_status.txt') as f:
            lines = f.readlines()
    except FileNotFoundError:
        print("인터페이스 상태 파일이 없습니다.")
        return ports

    for line in lines:
        # 헤더는 건너뛰기
        if line.strip().startswith('Interface') or not line.strip():
            continue

        # 공백으로 구분된 항목 파싱
        parts = line.strip().split()
        if len(parts) < 6:
            continue

        interface = parts[0]
        status = ' '.join(parts[4:-1])  # 상태가 공백 포함일 수 있음
        protocol = parts[-1]

        if interface.startswith("FastEthernet0/"):
            ports[interface] = {
                "status": status,
                "protocol": protocol
            }

    return ports
    
@app.route('/refresh') 
def refresh():
    try:
        # 예: show ip interface brief 실행 결과를 /tmp/int_status.txt에 저장
        cmd = ["ansible-playbook", "/etc/ansible/show_int.yml"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)

        if result.returncode == 0:
            return jsonify({'status': 'ok'})
        else:
            return jsonify({'status': 'error', 'message': result.stderr})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

def run_show_int():
    try:
        cmd = ["ansible-playbook", "/etc/ansible/show_int.yml"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        return result.returncode == 0, result.stderr
    except Exception as e:
        return False, str(e)

if __name__ == '__main__':
    run_show_int()
    app.run(debug=True)

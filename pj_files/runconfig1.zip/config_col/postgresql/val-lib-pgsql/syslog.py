import psycopg2
import re
from datetime import datetime

conn = psycopg2.connect("dbname=testdb1_1 user=pgsdb password=yourpassword host=localhost")
cur = conn.cursor()

with open('/var/log/remote/tacacs.log', 'r') as f:
    for line in f:
        # 예시: 'Jul 31 23:59:59 hostname tac_plus[12345]: 로그메시지'
        m = re.match(r'^(\w+ \d+ \d+:\d+:\d+) (\S+) tac_plus\[\d+\]: (.*)$', line)
        if m:
            log_time_str, hostname, message = m.groups()
            log_time = datetime.strptime(log_time_str, '%b %d %H:%M:%S')
            cur.execute("INSERT INTO tacacs_logs (log_time, hostname, service, message) VALUES (%s, %s, %s, %s)",
                        (log_time, hostname, 'tac_plus', message))

conn.commit()
cur.close()
conn.close()

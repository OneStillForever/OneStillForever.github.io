import psycopg2
import re
from datetime import datetime
import os

conn = psycopg2.connect(
    dbname="syslog",
    user="syslogdb",
    password="password",
    host="127.0.0.1",
    port="5432"
)
cur = conn.cursor()

logfile = '/var/log/cisco_rsyslog.log'
offset_file = '/var/lib/pgsql/tacacs_offset.txt'  # 마지막 읽은 위치 저장 파일

# 마지막으로 읽은 위치 불러오기
last_position = 0
if os.path.exists(offset_file):
    with open(offset_file, 'r') as f:
        try:
            last_position = int(f.read())
        except:
            pass

with open(logfile, 'r') as f:
    f.seek(last_position)  # 마지막 위치로 이동

    for line in f:
        m = re.match(r'^(\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2}) (\S+) \d+:  \*(.*)$', line)
        if m:
            log_time_str, hostname, full_message = m.groups()

            # 날짜 파싱 (연도 추가)
            try:
                log_time = datetime.strptime(log_time_str + f' {datetime.now().year}', '%b %d %H:%M:%S %Y')
            except ValueError:
                continue

            # 서비스/메시지 분리
            if ':' in full_message:
                service, message = full_message.split(":", 1)
                service = service.strip()
                message = message.strip()
            else:
                service = ''
                message = full_message.strip()

            # INSERT
            cur.execute("""
                INSERT INTO cisco_rsyslogs (log_time, hostname, service, message)
                VALUES (%s, %s, %s, %s)
            """, (log_time, hostname, service, message))

    # 마지막 위치 저장
    with open(offset_file, 'w') as f_offset:
        f_offset.write(str(f.tell()))

conn.commit()
cur.close()
conn.close()

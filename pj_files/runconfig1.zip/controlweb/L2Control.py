from flask import Flask, render_template, request, jsonify
import subprocess, re

app = Flask(__name__)

@app.route('/')
def index():
    target = request.args.get('target', 'L2Switch2')
    ports = parse_interface_status(target)
    return render_template('L2SW.html', ports=ports, target=target)

@app.route('/interface/<action>')
def interface_action(action):
    port = request.args.get('port')
    target = request.args.get('target', 'L2SW2')

    if action in ['shutdown', 'no shutdown']:  # 이미 HTML에서 제대로 넘어오므로 OK
        cmd = [
            'ansible-playbook', '/etc/ansible/interface_control.yml',
            '-e', f"target={target} port={port} act='{action}'"
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            print(f"Executing: {cmd}")
            if result.returncode == 0:
                return jsonify({'status': 'ok'})
            else:
                return jsonify({'status': 'error', 'message': result.stderr})
        except Exception as e:
            return jsonify({'status': 'error', 'message': str(e)})
    return jsonify({'status': 'error', 'message': '잘못된 명령'})

@app.route('/refresh')
def refresh():
    target = request.args.get('target', 'L2Switch2')
    cmd = [
        'ansible-playbook', '/etc/ansible/show_int_status.yml',
        '-l', target,
        '-e', f"target={target}"
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    # returncode가 0이면 stderr에 warning이 있든 없든 성공 처리
    if result.returncode == 0:
        return jsonify({'status': 'ok'})
    
    # returncode가 0이 아닌데 stderr에 warning뿐이라면 여전히 성공으로 간주할 수도 있음
    if 'WARNING:' in result.stderr and 'ERROR' not in result.stderr.upper():
        return jsonify({'status': 'ok_with_warnings', 'message': result.stderr})
    
    # 그 외는 진짜 실패
    return jsonify({'status': 'error', 'message': result.stderr})

def parse_interface_status(target):
    ports = {}
    path = f"/tmp/int_status_{target}.txt"

    # 정규표현식 패턴: 인터페이스, IP, OK?, Method, Status, Protocol
    pattern = re.compile(r'^(FastEthernet|GigabitEthernet)\S*\s+\S+\s+\S+\s+\S+\s+(.+?)\s+(up|down)$')

    try:
        with open(path) as f:
            for line in f:
                match = pattern.search(line.strip())
                if match:
                    port_full = line.strip().split()[0]  # 예: FastEthernet0/8
                    status = match.group(2).strip()       # 예: "administratively down"
                    protocol = match.group(3).strip()     # 예: "down"
                    ports[port_full] = {"status": status, "protocol": protocol}
    except FileNotFoundError:
        print(f"{path} 파일 없음")
    return ports

if __name__ == '__main__':
    app.run(debug=True)
